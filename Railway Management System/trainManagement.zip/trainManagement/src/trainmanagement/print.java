/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainmanagement;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author melvi
 */
public class print extends javax.swing.JFrame {

    /**
     * Creates new form print
     */
    public print() {
      initComponents();

    }
                 Connection con;
    PreparedStatement pst;
    public PageFormat getPageFormat(PrinterJob pj)
{
    
    PageFormat pf = pj.defaultPage();
    Paper paper = pf.getPaper();    

    double middleHeight =8.0;  
    double headerHeight = 2.0;                  
    double footerHeight = 2.0;                  
    double width = convert_CM_To_PPI(8);      //printer know only point per inch.default value is 72ppi
    double height = convert_CM_To_PPI(headerHeight+middleHeight+footerHeight); 
    paper.setSize(width, height);
    paper.setImageableArea(                    
        0,
        10,
        width,            
        height - convert_CM_To_PPI(1)
    );   //define boarder size    after that print area width is about 180 points
            
    pf.setOrientation(PageFormat.PORTRAIT);           //select orientation portrait or landscape but for this time portrait
    pf.setPaper(paper);    

    return pf;
}
    
    protected static double convert_CM_To_PPI(double cm) {            
	        return toPPI(cm * 0.393600787);            
}
 
protected static double toPPI(double inch) {            
	        return inch * 120d;            
}






public class BillPrintable implements Printable {
    
   
    
    
  public int print(Graphics graphics, PageFormat pageFormat,int pageIndex) 
  throws PrinterException 
  {    
      
                
        
      int result = NO_SUCH_PAGE;    
        if (pageIndex == 0) {                    
        
            Graphics2D g2d = (Graphics2D) graphics;                    

            double width = pageFormat.getImageableWidth();                    
           
            g2d.translate((int) pageFormat.getImageableX(),(int) pageFormat.getImageableY()); 

            ////////// code by alqama//////////////

            FontMetrics metrics=g2d.getFontMetrics(new Font("Arial",Font.BOLD,7));
        //    int idLength=metrics.stringWidth("000000");
            //int idLength=metrics.stringWidth("00");
            int idLength=metrics.stringWidth("000");
            int amtLength=metrics.stringWidth("000000");
            int qtyLength=metrics.stringWidth("00000");
            int priceLength=metrics.stringWidth("000000");
            int prodLength=(int)width - idLength - amtLength - qtyLength - priceLength-17;

        //    int idPosition=0;
        //    int productPosition=idPosition + idLength + 2;
        //    int pricePosition=productPosition + prodLength +10;
        //    int qtyPosition=pricePosition + priceLength + 2;
        //    int amtPosition=qtyPosition + qtyLength + 2;
            
            int productPosition = 0;
            int discountPosition= prodLength+5;
            int pricePosition = discountPosition +idLength+10;
            int qtyPosition=pricePosition + priceLength + 4;
            int amtPosition=qtyPosition + qtyLength;
            
   int ids = 0;         
   String pass =null;
   String tr = null;
   String st= null;
   String bo= null;
   String de= null;
   String to= null;
   String ri= null;
   String bd= null;
   String bt= null;
   String na= null;
   String ag= null;
   String ge= null;
   String pr= null;
   String mo= null;
   String nu= null;
   
   PrinterJob pj = PrinterJob.getPrinterJob();
   pj.setPrintable(new BillPrintable(),getPageFormat(pj));
   

   
        try{
            /*Draw Header*/
            int y=20;
            int yShift = 10;
            int headerRectHeight=15;
            int headerRectHeighta=40;
                   
            Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection("jdbc:mysql://localhost:3306/trainmanagement","root","");
         
         		pst = con .prepareStatement("SELECT *\n" +
"FROM reservation\n" +
"WHERE id = ( SELECT MAX(id) FROM reservation ) ;" );
			ResultSet rs = pst.executeQuery();
                        
                        if(rs.next())
                        {
                            ids =rs.getInt("id");
                            pass =rs.getString("password");                            
                            tr =rs.getString("train");
                            st =rs.getString("station");
                            bo =rs.getString("board");
                            de =rs.getString("dest");
                            to =rs.getString("todest");
                            ri =rs.getString("ride");                            
                            bd =rs.getString("bookingdate");
                            bt =rs.getString("bookingtime");
                            na =rs.getString("name");
                            ag =rs.getString("age");
                            ge =rs.getString("gender");
                            pr =rs.getString("price");
                            mo =rs.getString("mode");
                            nu =rs.getString("number");
                            
                        }
			
            
            ///////////////// Product names Get ///////////

            ///////////////// Product names Get ///////////
                
            
            ///////////////// Product price Get ///////////
 
            ///////////////// Product price Get ///////////
                
             /**g2d.setFont(new Font("Monospaced",Font.PLAIN,9));
            g2d.drawString("-------------------------------------",12,y);y+=yShift;
            g2d.drawString("        Train Management Slip        ",12,y);y+=yShift;
            g2d.drawString("-------------------------------------",12,y);y+=headerRectHeight;
      
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString(" Receipt ID                "+ids+"   ",10,y);y+=yShift;
            g2d.drawString("-------------------------------------",10,y);y+=headerRectHeight;
            g2d.drawString(" Train ID                  "+tr+"  ",10,y);y+=yShift;
            g2d.drawString(" Riding Station            "+st+"  ",10,y);y+=yShift;
            g2d.drawString(" Boarding Time             "+bo+"  ",10,y);y+=yShift;
            g2d.drawString(" Destination               "+de+"  ",10,y);y+=yShift;
            g2d.drawString(" Time to Destination       "+to+"  ",10,y);y+=yShift;
            g2d.drawString(" Date of Ride              "+ri+"  ",10,y);y+=yShift;
            g2d.drawString(" Booking Date              "+bd+"  ",10,y);y+=yShift;
            g2d.drawString(" Booking Time              "+bt+"  ",10,y);y+=yShift;
            g2d.drawString(" Name                      "+na+"  ",10,y);y+=yShift;
            g2d.drawString(" age                       "+ag+"  ",10,y);y+=yShift;
            g2d.drawString(" gender                    "+ge+"  ",10,y);y+=yShift;
            g2d.drawString(" price                     "+pr+"  ",10,y);y+=yShift;
            g2d.drawString(" mode                      "+mo+"  ",10,y);y+=yShift;
            g2d.drawString(" Number                    "+nu+"  ",10,y);y+=yShift;  
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString("           Train Management          ",10,y);y+=yShift;
            g2d.drawString("*************************************",10,y);y+=yShift;
            g2d.drawString("         Lorem ipsum dolor sit       ",10,y);y+=yShift;
            g2d.drawString("*************************************",10,y);y+=yShift;**/
                   
           g2d.setFont(new Font("Monospaced",Font.PLAIN,9));
            g2d.drawString("-------------------------------------",12,y);y+=yShift;
            g2d.drawString("              ABC Train              ",12,y);y+=yShift;
            g2d.drawString("-------------------------------------",12,y);y+=headerRectHeight;
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString(" Receipt ID                "+ids+"   ",10,y);y+=yShift;
            g2d.drawString("-------------------------------------",10,y);y+=headerRectHeight;
            g2d.drawString(" Train ID                  "+tr+"  ",10,y);y+=yShift;
            g2d.drawString(" Riding Station            "+st+"  ",10,y);y+=yShift;
            g2d.drawString(" Boarding Time             "+bo+"  ",10,y);y+=yShift;
            g2d.drawString(" Destination               "+de+"  ",10,y);y+=yShift;
            g2d.drawString(" Time to Destination       "+to+"  ",10,y);y+=yShift;
            g2d.drawString(" Date of Ride              "+ri+"  ",10,y);y+=yShift;
            g2d.drawString(" Booking Date              "+bd+"  ",10,y);y+=yShift;
            g2d.drawString(" Booking Time              "+bt+"  ",10,y);y+=yShift;
            g2d.drawString(" Name                      "+na+"  ",10,y);y+=yShift;
            g2d.drawString(" age                       "+ag+"  ",10,y);y+=yShift;
            g2d.drawString(" gender                    "+ge+"  ",10,y);y+=yShift;
            g2d.drawString(" price                     "+pr+"  ",10,y);y+=yShift;
            g2d.drawString(" mode                      "+mo+"  ",10,y);y+=yShift;
            g2d.drawString(" Number                    "+nu+"  ",10,y);y+=yShift;  
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString("-------------------------------------",10,y);y+=yShift;
            g2d.drawString("   Bring your printed ticket upon    ",10,y);y+=yShift;
            g2d.drawString("rebooking of your journey to another ",10,y);y+=yShift;
            g2d.drawString("   place or another date until the   ",10,y);y+=yShift;
            g2d.drawString(" the departure of the train, you can ",10,y);y+=yShift;
            g2d.drawString("   also cancel the booking 24 hours  ",10,y);y+=yShift;
            g2d.drawString("    before the scheduled departure.  ",10,y);y+=yShift;
            g2d.drawString("    You will then receive a refund   ",10,y);y+=yShift;
            g2d.drawString("          of ticket price.           ",10,y);y+=yShift;
            g2d.drawString("*************************************",10,y);y+=yShift;
            g2d.drawString("Call: 02 740 3819 8:00 am to 5:00 pm ",10,y);y+=yShift;
            g2d.drawString("    Monday to Friday for reporting   ",10,y);y+=yShift;
            g2d.drawString("         any problems occured.       ",10,y);y+=yShift;
            g2d.drawString("                                     ",10,y);y+=yShift;
            g2d.drawString("     If you are a traveller with     ",10,y);y+=yShift;
            g2d.drawString("            disabilities,            ",10,y);y+=yShift;
            g2d.drawString("  Call: 419 282 2917 for assistance  ",10,y);y+=yShift;
            g2d.drawString("*************************************",10,y);y+=yShift;
      
           
            
//            g2d.setFont(new Font("Monospaced",Font.BOLD,10));
//            g2d.drawString("Customer Shopping Invoice", 30,y);y+=yShift; 
          

    }
    catch(  ClassNotFoundException | SQLException r){
    }
       
              result = PAGE_EXISTS;    
          }    
          return result;    
      }
   } 
    
    


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(250, 250));

        jButton1.setText("PRINT.");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Click \"PRINT\" to print your ticket.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(151, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(146, 146, 146)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(161, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

                PrinterJob pj = PrinterJob.getPrinterJob();        
        pj.setPrintable(new BillPrintable(),getPageFormat(pj));
        try {
             pj.print();
          this.dispose();
          optionForm of = new optionForm();
          of.setVisible(true);
        }
         catch (PrinterException ex) {
                 ex.printStackTrace();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(print.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(print.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(print.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(print.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new print().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
