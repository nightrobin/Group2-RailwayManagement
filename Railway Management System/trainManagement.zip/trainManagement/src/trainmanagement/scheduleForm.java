/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainmanagement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author melvi
 */
public class scheduleForm extends javax.swing.JFrame {
    String filename = null;
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null; 
    /**
     * Creates new form scheduleForm
     */
    public scheduleForm() {
        initComponents();
        showTime();
        showDate();
        disenyo();
       restriction();
        con = db.mycon();
    }
    
    public void restriction()
    {

        
        Date date = new Date();
        
            jCalendar1.getDayChooser().setMinSelectableDate(date);
                
    }
    
    public void disenyo()
    {
      stationA.setVisible(false);  
      stationBNorth.setVisible(false); 
      stationBSouth.setVisible(false); 
      stationC.setVisible(false); 
      comboA.setVisible(false);
      comboBNorth.setVisible(false);
      comboBSouth.setVisible(false);
      comboC.setVisible(false);
    }
    
    void showDate()
    {
     SimpleDateFormat time = new SimpleDateFormat("yyyy/MM/dd");
      Date d = new Date();     
      dateDisplay.setText(time.format(d));
      book.setText(time.format(d));
    }

    public void showTime()
    {
        new Timer(0, new ActionListener()
        {
          @Override
          public void actionPerformed(ActionEvent e){
              SimpleDateFormat time = new SimpleDateFormat("hh:mm:ss a");
              Date d = new Date();
              timedisplay.setText(time.format(d));
              timerist.setText(time.format(d));              
          }
       
        }).start();
                
    }
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        timedisplay = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        dateDisplay = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        stationA = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        trainid = new javax.swing.JLabel();
        times = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jPanel24 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jButton25 = new javax.swing.JButton();
        jPanel27 = new javax.swing.JPanel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jButton28 = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jButton30 = new javax.swing.JButton();
        jPanel43 = new javax.swing.JPanel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jButton43 = new javax.swing.JButton();
        jPanel44 = new javax.swing.JPanel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jButton44 = new javax.swing.JButton();
        jPanel45 = new javax.swing.JPanel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jButton45 = new javax.swing.JButton();
        jPanel46 = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jButton46 = new javax.swing.JButton();
        jPanel47 = new javax.swing.JPanel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jButton47 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        stationBNorth = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jPanel30 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jButton31 = new javax.swing.JButton();
        jPanel32 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jButton32 = new javax.swing.JButton();
        jPanel33 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jButton33 = new javax.swing.JButton();
        jPanel34 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jButton34 = new javax.swing.JButton();
        jPanel35 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jButton35 = new javax.swing.JButton();
        jPanel36 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jButton36 = new javax.swing.JButton();
        jPanel37 = new javax.swing.JPanel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jButton37 = new javax.swing.JButton();
        jPanel39 = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jButton39 = new javax.swing.JButton();
        jPanel40 = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jButton40 = new javax.swing.JButton();
        jPanel41 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jButton41 = new javax.swing.JButton();
        jPanel48 = new javax.swing.JPanel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jButton48 = new javax.swing.JButton();
        jPanel49 = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jButton49 = new javax.swing.JButton();
        jPanel50 = new javax.swing.JPanel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jButton50 = new javax.swing.JButton();
        jPanel51 = new javax.swing.JPanel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jButton51 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        stationBSouth = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jPanel38 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jButton38 = new javax.swing.JButton();
        jPanel67 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jButton42 = new javax.swing.JButton();
        jPanel68 = new javax.swing.JPanel();
        jLabel137 = new javax.swing.JLabel();
        jLabel138 = new javax.swing.JLabel();
        jButton66 = new javax.swing.JButton();
        jPanel69 = new javax.swing.JPanel();
        jLabel139 = new javax.swing.JLabel();
        jLabel140 = new javax.swing.JLabel();
        jButton67 = new javax.swing.JButton();
        jPanel70 = new javax.swing.JPanel();
        jLabel141 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        jButton68 = new javax.swing.JButton();
        jPanel71 = new javax.swing.JPanel();
        jLabel143 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jButton69 = new javax.swing.JButton();
        jPanel72 = new javax.swing.JPanel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        jButton70 = new javax.swing.JButton();
        jPanel73 = new javax.swing.JPanel();
        jLabel147 = new javax.swing.JLabel();
        jLabel148 = new javax.swing.JLabel();
        jButton71 = new javax.swing.JButton();
        jPanel74 = new javax.swing.JPanel();
        jLabel149 = new javax.swing.JLabel();
        jLabel150 = new javax.swing.JLabel();
        jButton72 = new javax.swing.JButton();
        jPanel75 = new javax.swing.JPanel();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jButton73 = new javax.swing.JButton();
        jPanel76 = new javax.swing.JPanel();
        jLabel153 = new javax.swing.JLabel();
        jLabel154 = new javax.swing.JLabel();
        jButton74 = new javax.swing.JButton();
        jPanel77 = new javax.swing.JPanel();
        jLabel155 = new javax.swing.JLabel();
        jLabel156 = new javax.swing.JLabel();
        jButton75 = new javax.swing.JButton();
        jPanel78 = new javax.swing.JPanel();
        jLabel157 = new javax.swing.JLabel();
        jLabel158 = new javax.swing.JLabel();
        jButton76 = new javax.swing.JButton();
        jPanel79 = new javax.swing.JPanel();
        jLabel159 = new javax.swing.JLabel();
        jLabel160 = new javax.swing.JLabel();
        jButton77 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        stationC = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jPanel52 = new javax.swing.JPanel();
        jLabel107 = new javax.swing.JLabel();
        jPanel53 = new javax.swing.JPanel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jButton52 = new javax.swing.JButton();
        jPanel54 = new javax.swing.JPanel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jButton53 = new javax.swing.JButton();
        jPanel55 = new javax.swing.JPanel();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jButton54 = new javax.swing.JButton();
        jPanel56 = new javax.swing.JPanel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jButton55 = new javax.swing.JButton();
        jPanel57 = new javax.swing.JPanel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jButton56 = new javax.swing.JButton();
        jPanel58 = new javax.swing.JPanel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jButton57 = new javax.swing.JButton();
        jPanel59 = new javax.swing.JPanel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jButton58 = new javax.swing.JButton();
        jPanel60 = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jButton59 = new javax.swing.JButton();
        jPanel61 = new javax.swing.JPanel();
        jLabel124 = new javax.swing.JLabel();
        jLabel125 = new javax.swing.JLabel();
        jButton60 = new javax.swing.JButton();
        jPanel62 = new javax.swing.JPanel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jButton61 = new javax.swing.JButton();
        jPanel63 = new javax.swing.JPanel();
        jLabel128 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        jButton62 = new javax.swing.JButton();
        jPanel64 = new javax.swing.JPanel();
        jLabel130 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        jButton63 = new javax.swing.JButton();
        jPanel65 = new javax.swing.JPanel();
        jLabel132 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        jButton64 = new javax.swing.JButton();
        jPanel66 = new javax.swing.JPanel();
        jLabel134 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        jButton65 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jLabel83 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        trainNumber = new javax.swing.JLabel();
        stationOutput = new javax.swing.JLabel();
        boardTime = new javax.swing.JLabel();
        destiny = new javax.swing.JLabel();
        destinyTime = new javax.swing.JLabel();
        dated = new javax.swing.JLabel();
        book = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        timerist = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        nameLabel = new javax.swing.JLabel();
        ageLabel = new javax.swing.JLabel();
        genderLabel = new javax.swing.JLabel();
        priceLabel = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        idLabel = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        comboC = new javax.swing.JComboBox<>();
        comboA = new javax.swing.JComboBox<>();
        comboBNorth = new javax.swing.JComboBox<>();
        comboBSouth = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        passwordLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(900, 650));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("TIME:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(501, 15, -1, -1));

        timedisplay.setFont(new java.awt.Font("Engravers MT", 1, 14)); // NOI18N
        timedisplay.setText("jLabel2");
        getContentPane().add(timedisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(547, 11, -1, -1));

        jLabel2.setText("Date:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(502, 38, -1, -1));

        dateDisplay.setFont(new java.awt.Font("Engravers MT", 1, 14)); // NOI18N
        dateDisplay.setText("jLabel2");
        getContentPane().add(dateDisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(547, 35, -1, -1));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setAutoscrolls(true);
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("Station A");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 30, 80, 49));

        jButton1.setText("Station B(SB)");
        jButton1.setActionCommand("Station B\nNorth");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 80, 50));

        jButton4.setText("Station C");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 80, 49));

        jButton3.setText("Station B(NB)");
        jButton3.setActionCommand("Station B\nNorth");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 80, 50));

        jScrollPane1.setViewportView(jPanel3);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 130, 200));

        jLabel3.setFont(new java.awt.Font("MS UI Gothic", 1, 24)); // NOI18N
        jLabel3.setText("Train Boarding Schedules");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, -1, -1));

        jLabel17.setFont(new java.awt.Font("MS UI Gothic", 1, 24)); // NOI18N
        jLabel17.setText("Stations");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("MS UI Gothic", 1, 24)); // NOI18N
        jLabel16.setText("Station A");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel7.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setText("Train 001");
        jPanel7.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel13.setText("11:00 AM");
        jPanel7.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton11.setText("Pick");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 60, -1, -1));

        jPanel2.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        trainid.setText("Train 001");
        jPanel2.add(trainid, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        times.setText("5:00 AM");
        jPanel2.add(times, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton7.setText("Pick");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 120, 120));

        jPanel4.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setText("Train 002");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel7.setText("6:00 AM");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton8.setText("Pick");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        jPanel5.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setText("Train 003");
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel9.setText("7:00 AM");
        jPanel5.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton9.setText("Pick");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, -1, -1));

        jPanel6.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setText("Train 004");
        jPanel6.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel11.setText("8:00 AM");
        jPanel6.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton10.setText("Pick");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, -1, -1));

        jPanel8.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setText("Train 005");
        jPanel8.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel15.setText("9:00 AM");
        jPanel8.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton12.setText("Pick");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        jPanel24.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel44.setText("Train 006");
        jPanel24.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel45.setText("10:00 AM");
        jPanel24.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton25.setText("Pick");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, -1, -1));

        jPanel27.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel50.setText("Train 002");
        jPanel27.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel51.setText("12:00 PM");
        jPanel27.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton28.setText("Pick");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 60, -1, -1));

        jPanel29.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel54.setText("Train 002");
        jPanel29.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel55.setText("6:00 PM");
        jPanel29.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton30.setText("Pick");
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton30, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(1840, 60, -1, -1));

        jPanel43.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel43.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel81.setText("Train 003");
        jPanel43.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel82.setText("1:00 PM");
        jPanel43.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton43.setText("Pick");
        jButton43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton43ActionPerformed(evt);
            }
        });
        jPanel43.add(jButton43, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 60, -1, -1));

        jPanel44.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel44.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel91.setText("Train 004");
        jPanel44.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel92.setText("2:00 PM");
        jPanel44.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton44.setText("Pick");
        jButton44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton44ActionPerformed(evt);
            }
        });
        jPanel44.add(jButton44, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 60, -1, -1));

        jPanel45.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel45.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel93.setText("Train 005");
        jPanel45.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel94.setText("3:00 PM");
        jPanel45.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton45.setText("Pick");
        jButton45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton45ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton45, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 60, -1, -1));

        jPanel46.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel46.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel95.setText("Train 006");
        jPanel46.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel96.setText("4:00 PM");
        jPanel46.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton46.setText("Pick");
        jButton46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton46ActionPerformed(evt);
            }
        });
        jPanel46.add(jButton46, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 60, -1, -1));

        jPanel47.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel47.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel97.setText("Train 001");
        jPanel47.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel98.setText("5:00 PM");
        jPanel47.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton47.setText("Pick");
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });
        jPanel47.add(jButton47, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel1.add(jPanel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(1690, 60, -1, -1));

        jLabel18.setText("(NORTHBOUND TRAINS)");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        jScrollPane2.setViewportView(jPanel1);

        javax.swing.GroupLayout stationALayout = new javax.swing.GroupLayout(stationA);
        stationA.setLayout(stationALayout);
        stationALayout.setHorizontalGroup(
            stationALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
        );
        stationALayout.setVerticalGroup(
            stationALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stationALayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        getContentPane().add(stationA, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 480, 200));

        jScrollPane5.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane5.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel30.setBackground(new java.awt.Color(204, 204, 204));
        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel56.setFont(new java.awt.Font("MS UI Gothic", 1, 24)); // NOI18N
        jLabel56.setText("Station B");
        jPanel30.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel31.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel57.setText("Train 006");
        jPanel31.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel58.setText("11:00 PM");
        jPanel31.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton31.setText("Pick");
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });
        jPanel31.add(jButton31, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 60, -1, -1));

        jPanel32.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel59.setText("Train 006");
        jPanel32.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel60.setText("5:00 AM");
        jPanel32.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton32.setText("Pick");
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });
        jPanel32.add(jButton32, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 120, 120));

        jPanel33.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel33.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel61.setText("Train 001");
        jPanel33.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel62.setText("6:00 AM");
        jPanel33.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton33.setText("Pick");
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });
        jPanel33.add(jButton33, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        jPanel34.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel34.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel63.setText("Train 002");
        jPanel34.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel64.setText("7:00 AM");
        jPanel34.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton34.setText("Pick");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });
        jPanel34.add(jButton34, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, -1, -1));

        jPanel35.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel35.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel65.setText("Train 003");
        jPanel35.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel66.setText("8:00 AM");
        jPanel35.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton35.setText("Pick");
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel35.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, -1, -1));

        jPanel36.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel36.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel67.setText("Train 004");
        jPanel36.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel68.setText("9:00 AM");
        jPanel36.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton36.setText("Pick");
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });
        jPanel36.add(jButton36, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        jPanel37.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel37.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel69.setText("Train 005");
        jPanel37.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel70.setText("10:00 AM");
        jPanel37.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton37.setText("Pick");
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });
        jPanel37.add(jButton37, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, -1, -1));

        jPanel39.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel39.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel73.setText("Train 001");
        jPanel39.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel74.setText("12:00 PM");
        jPanel39.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton39.setText("Pick");
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });
        jPanel39.add(jButton39, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 60, -1, -1));

        jPanel40.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel40.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel75.setText("Train 002");
        jPanel40.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel76.setText("1:00 PM");
        jPanel40.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton40.setText("Pick");
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });
        jPanel40.add(jButton40, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 60, -1, -1));

        jPanel41.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel41.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel77.setText("Train 001");
        jPanel41.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel78.setText("6:00 PM");
        jPanel41.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton41.setText("Pick");
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });
        jPanel41.add(jButton41, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(1830, 60, -1, -1));

        jPanel48.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel48.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel99.setText("Train 003");
        jPanel48.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel100.setText("2:00 PM");
        jPanel48.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton48.setText("Pick");
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });
        jPanel48.add(jButton48, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 60, -1, -1));

        jPanel49.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel49.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel101.setText("Train 004");
        jPanel49.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel102.setText("3:00 PM");
        jPanel49.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton49.setText("Pick");
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });
        jPanel49.add(jButton49, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 60, -1, -1));

        jPanel50.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel50.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel103.setText("Train 005");
        jPanel50.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel104.setText("4:00 PM");
        jPanel50.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton50.setText("Pick");
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });
        jPanel50.add(jButton50, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 60, -1, -1));

        jPanel51.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel51.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel105.setText("Train 006");
        jPanel51.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel106.setText("5:00 PM");
        jPanel51.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton51.setText("Pick");
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });
        jPanel51.add(jButton51, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel30.add(jPanel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(1690, 60, -1, -1));

        jLabel19.setText("(NORTHBOUND TRAINS)");
        jPanel30.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        jScrollPane5.setViewportView(jPanel30);

        javax.swing.GroupLayout stationBNorthLayout = new javax.swing.GroupLayout(stationBNorth);
        stationBNorth.setLayout(stationBNorthLayout);
        stationBNorthLayout.setHorizontalGroup(
            stationBNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stationBNorthLayout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        stationBNorthLayout.setVerticalGroup(
            stationBNorthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stationBNorthLayout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        getContentPane().add(stationBNorth, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 480, 200));

        jScrollPane7.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane7.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel38.setBackground(new java.awt.Color(204, 204, 204));
        jPanel38.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel71.setFont(new java.awt.Font("MS UI Gothic", 1, 24)); // NOI18N
        jLabel71.setText("Station B");
        jPanel38.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel42.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel42.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel72.setText("Train 003");
        jPanel42.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel79.setText("11:00 PM");
        jPanel42.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton38.setText("Pick");
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });
        jPanel42.add(jButton38, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 60, -1, -1));

        jPanel67.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel67.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel80.setText("Train 003");
        jPanel67.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel136.setText("5:00 AM");
        jPanel67.add(jLabel136, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton42.setText("Pick");
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });
        jPanel67.add(jButton42, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 120, 120));

        jPanel68.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel68.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel137.setText("Train 004");
        jPanel68.add(jLabel137, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel138.setText("6:00 AM");
        jPanel68.add(jLabel138, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton66.setText("Pick");
        jButton66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton66ActionPerformed(evt);
            }
        });
        jPanel68.add(jButton66, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        jPanel69.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel69.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel139.setText("Train 005");
        jPanel69.add(jLabel139, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel140.setText("7:00 AM");
        jPanel69.add(jLabel140, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton67.setText("Pick");
        jButton67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton67ActionPerformed(evt);
            }
        });
        jPanel69.add(jButton67, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, -1, -1));

        jPanel70.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel70.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel141.setText("Train 006");
        jPanel70.add(jLabel141, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel142.setText("8:00 AM");
        jPanel70.add(jLabel142, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton68.setText("Pick");
        jButton68.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton68ActionPerformed(evt);
            }
        });
        jPanel70.add(jButton68, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, -1, -1));

        jPanel71.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel71.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel143.setText("Train 001");
        jPanel71.add(jLabel143, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel144.setText("9:00 AM");
        jPanel71.add(jLabel144, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton69.setText("Pick");
        jButton69.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton69ActionPerformed(evt);
            }
        });
        jPanel71.add(jButton69, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        jPanel72.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel72.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel145.setText("Train 002");
        jPanel72.add(jLabel145, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel146.setText("10:00 AM");
        jPanel72.add(jLabel146, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton70.setText("Pick");
        jButton70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton70ActionPerformed(evt);
            }
        });
        jPanel72.add(jButton70, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, -1, -1));

        jPanel73.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel73.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel147.setText("Train 004");
        jPanel73.add(jLabel147, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel148.setText("12:00 PM");
        jPanel73.add(jLabel148, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton71.setText("Pick");
        jButton71.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton71ActionPerformed(evt);
            }
        });
        jPanel73.add(jButton71, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 60, -1, -1));

        jPanel74.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel74.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel149.setText("Train 005");
        jPanel74.add(jLabel149, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel150.setText("1:00 PM");
        jPanel74.add(jLabel150, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton72.setText("Pick");
        jButton72.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton72ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton72, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 60, -1, -1));

        jPanel75.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel75.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel151.setText("Train 003");
        jPanel75.add(jLabel151, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel152.setText("6:00 PM");
        jPanel75.add(jLabel152, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton73.setText("Pick");
        jButton73.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton73ActionPerformed(evt);
            }
        });
        jPanel75.add(jButton73, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(1830, 60, -1, -1));

        jPanel76.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel76.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel153.setText("Train 006");
        jPanel76.add(jLabel153, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel154.setText("2:00 PM");
        jPanel76.add(jLabel154, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton74.setText("Pick");
        jButton74.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton74ActionPerformed(evt);
            }
        });
        jPanel76.add(jButton74, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 60, -1, -1));

        jPanel77.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel77.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel155.setText("Train 001");
        jPanel77.add(jLabel155, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel156.setText("3:00 PM");
        jPanel77.add(jLabel156, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton75.setText("Pick");
        jButton75.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton75ActionPerformed(evt);
            }
        });
        jPanel77.add(jButton75, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 60, -1, -1));

        jPanel78.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel78.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel157.setText("Train 002");
        jPanel78.add(jLabel157, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel158.setText("4:00 PM");
        jPanel78.add(jLabel158, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton76.setText("Pick");
        jButton76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton76ActionPerformed(evt);
            }
        });
        jPanel78.add(jButton76, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 60, -1, -1));

        jPanel79.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel79.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel159.setText("Train 003");
        jPanel79.add(jLabel159, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel160.setText("5:00 PM");
        jPanel79.add(jLabel160, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton77.setText("Pick");
        jButton77.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton77ActionPerformed(evt);
            }
        });
        jPanel79.add(jButton77, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel38.add(jPanel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(1690, 60, -1, -1));

        jLabel21.setText("(SOUTHBOUND TRAINS)");
        jPanel38.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        jScrollPane7.setViewportView(jPanel38);

        javax.swing.GroupLayout stationBSouthLayout = new javax.swing.GroupLayout(stationBSouth);
        stationBSouth.setLayout(stationBSouthLayout);
        stationBSouthLayout.setHorizontalGroup(
            stationBSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stationBSouthLayout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        stationBSouthLayout.setVerticalGroup(
            stationBSouthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stationBSouthLayout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        getContentPane().add(stationBSouth, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 480, 200));

        jScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane6.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel52.setBackground(new java.awt.Color(204, 204, 204));
        jPanel52.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel107.setFont(new java.awt.Font("MS UI Gothic", 1, 24)); // NOI18N
        jLabel107.setText("Station C");
        jPanel52.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel53.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel53.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel108.setText("Train 004");
        jPanel53.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel109.setText("11:00 PM");
        jPanel53.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton52.setText("Pick");
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });
        jPanel53.add(jButton52, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 60, -1, -1));

        jPanel54.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel54.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel110.setText("Train 004");
        jPanel54.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel111.setText("5:00 AM");
        jPanel54.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton53.setText("Pick");
        jButton53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton53ActionPerformed(evt);
            }
        });
        jPanel54.add(jButton53, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 120, 120));

        jPanel55.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel55.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel112.setText("Train 005");
        jPanel55.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel113.setText("6:00 AM");
        jPanel55.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton54.setText("Pick");
        jButton54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton54ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton54, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        jPanel56.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel56.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel114.setText("Train 006");
        jPanel56.add(jLabel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel115.setText("7:00 AM");
        jPanel56.add(jLabel115, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton55.setText("Pick");
        jButton55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton55ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton55, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, -1, -1));

        jPanel57.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel57.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel116.setText("Train 001");
        jPanel57.add(jLabel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel117.setText("8:00 AM");
        jPanel57.add(jLabel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton56.setText("Pick");
        jButton56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton56ActionPerformed(evt);
            }
        });
        jPanel57.add(jButton56, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, -1, -1));

        jPanel58.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel58.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel118.setText("Train 002");
        jPanel58.add(jLabel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel119.setText("9:00 AM");
        jPanel58.add(jLabel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton57.setText("Pick");
        jButton57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton57ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton57, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        jPanel59.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel59.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel120.setText("Train 003");
        jPanel59.add(jLabel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel121.setText("10:00 AM");
        jPanel59.add(jLabel121, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton58.setText("Pick");
        jButton58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton58ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton58, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, -1, -1));

        jPanel60.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel60.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel122.setText("Train 005");
        jPanel60.add(jLabel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel123.setText("12:00 PM");
        jPanel60.add(jLabel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton59.setText("Pick");
        jButton59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton59ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton59, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 60, -1, -1));

        jPanel61.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel61.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel124.setText("Train 006");
        jPanel61.add(jLabel124, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, 50, -1));

        jLabel125.setText("1:00 PM");
        jPanel61.add(jLabel125, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton60.setText("Pick");
        jButton60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton60ActionPerformed(evt);
            }
        });
        jPanel61.add(jButton60, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 60, -1, -1));

        jPanel62.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel62.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel126.setText("Train 005");
        jPanel62.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel127.setText("6:00 PM");
        jPanel62.add(jLabel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton61.setText("Pick");
        jButton61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton61ActionPerformed(evt);
            }
        });
        jPanel62.add(jButton61, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(1830, 60, -1, -1));

        jPanel63.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel63.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel128.setText("Train 001");
        jPanel63.add(jLabel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel129.setText("2:00 PM");
        jPanel63.add(jLabel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton62.setText("Pick");
        jButton62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton62ActionPerformed(evt);
            }
        });
        jPanel63.add(jButton62, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 60, -1, -1));

        jPanel64.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel64.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel130.setText("Train 002");
        jPanel64.add(jLabel130, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel131.setText("3:00 PM");
        jPanel64.add(jLabel131, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton63.setText("Pick");
        jButton63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton63ActionPerformed(evt);
            }
        });
        jPanel64.add(jButton63, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 60, -1, -1));

        jPanel65.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel65.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel132.setText("Train 003");
        jPanel65.add(jLabel132, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel133.setText("4:00 PM");
        jPanel65.add(jLabel133, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton64.setText("Pick");
        jButton64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton64ActionPerformed(evt);
            }
        });
        jPanel65.add(jButton64, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 60, -1, -1));

        jPanel66.setPreferredSize(new java.awt.Dimension(120, 120));
        jPanel66.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel134.setText("Train 004");
        jPanel66.add(jLabel134, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 11, -1, -1));

        jLabel135.setText("5:00 PM");
        jPanel66.add(jLabel135, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 43, -1, -1));

        jButton65.setText("Pick");
        jButton65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton65ActionPerformed(evt);
            }
        });
        jPanel66.add(jButton65, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 75, -1, -1));

        jPanel52.add(jPanel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(1690, 60, -1, -1));

        jLabel20.setText("(SOUTHBOUND TRAINS)");
        jPanel52.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        jScrollPane6.setViewportView(jPanel52);

        javax.swing.GroupLayout stationCLayout = new javax.swing.GroupLayout(stationC);
        stationC.setLayout(stationCLayout);
        stationCLayout.setHorizontalGroup(
            stationCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stationCLayout.createSequentialGroup()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );
        stationCLayout.setVerticalGroup(
            stationCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getContentPane().add(stationC, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 480, 200));

        jCalendar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCalendar1MouseClicked(evt);
            }
        });
        jCalendar1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jCalendar1PropertyChange(evt);
            }
        });
        jCalendar1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jCalendar1KeyPressed(evt);
            }
        });
        getContentPane().add(jCalendar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 360, -1, -1));

        jLabel83.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel83.setText("Date of ride");
        getContentPane().add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, -1, -1));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setPreferredSize(new java.awt.Dimension(250, 250));
        jPanel9.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jPanel9PropertyChange(evt);
            }
        });

        jLabel84.setText("Schedule information");

        jLabel85.setText("Train No.");

        jLabel86.setText("Station:");

        jLabel87.setText("Boarding Time");

        jLabel88.setText("Destination");

        jLabel89.setText("Time to Destination");

        jLabel22.setText("Date of ride");

        jLabel23.setText("Date of Booking");

        jLabel26.setText("Price:");

        boardTime.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                boardTimePropertyChange(evt);
            }
        });

        destiny.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                destinyPropertyChange(evt);
            }
        });

        jLabel25.setText("Time of Booking:");

        jLabel4.setText("Name of Passenger:");

        jLabel5.setText("Age:");

        jLabel24.setText("Gender:");

        nameLabel.setText("jLabel26");

        ageLabel.setText("jLabel27");

        genderLabel.setText("jLabel28");

        jLabel27.setText("ID No.:");

        idLabel.setText("--");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel84)
                        .addGap(27, 27, 27)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(idLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel85)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(trainNumber))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel86)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(stationOutput))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel87)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(boardTime))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel88)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(destiny))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel89)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(destinyTime))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel23)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(book))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(timerist))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel22)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(dated))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ageLabel))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel24)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(genderLabel))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                                        .addComponent(jLabel26)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(priceLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(nameLabel)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel84)
                    .addComponent(jLabel27)
                    .addComponent(idLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel85)
                    .addComponent(trainNumber))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel86)
                    .addComponent(stationOutput))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel87)
                    .addComponent(boardTime))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel88)
                    .addComponent(destiny))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel89)
                    .addComponent(destinyTime))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(dated))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(book))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel25)
                    .addComponent(timerist))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(nameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(ageLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(genderLabel))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel26))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(priceLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, -1, 400));

        jLabel90.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel90.setText("Destination:");
        getContentPane().add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));

        comboC.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Station B", "Station A" }));
        comboC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboCActionPerformed(evt);
            }
        });
        getContentPane().add(comboC, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        comboA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Station B", "Station C" }));
        comboA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboAActionPerformed(evt);
            }
        });
        getContentPane().add(comboA, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        comboBNorth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Station C" }));
        comboBNorth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBNorthActionPerformed(evt);
            }
        });
        getContentPane().add(comboBNorth, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        comboBSouth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Station A", " " }));
        comboBSouth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBSouthActionPerformed(evt);
            }
        });
        getContentPane().add(comboBSouth, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        jButton5.setBackground(new java.awt.Color(102, 255, 102));
        jButton5.setText("RESERVE NOW!!!");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 490, 180, 70));

        passwordLabel.setText("jLabel28");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(passwordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(passwordLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 500, 10, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   
      stationA.setVisible(false);  
      stationBNorth.setVisible(false); 
      stationBSouth.setVisible(true); 
      stationC.setVisible(false); 
      comboA.setVisible(false);
      comboBNorth.setVisible(false);
      comboBSouth.setVisible(true);
      comboC.setVisible(false);

      stationOutput.setText("Station B(SouthBound)");
      
       String selectedValue = comboBSouth.getSelectedItem().toString();
        destiny.setText(selectedValue);
 
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    
      stationA.setVisible(false);  
      stationBNorth.setVisible(true); 
      stationBSouth.setVisible(false); 
      stationC.setVisible(false); 
      comboA.setVisible(false);
      comboBNorth.setVisible(true);
      comboBSouth.setVisible(false);
      comboC.setVisible(false);

      stationOutput.setText("Station B(NorthBound)");
       String selectedValue = comboBNorth.getSelectedItem().toString();
        destiny.setText(selectedValue);
 

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void comboAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboAActionPerformed
        String selectedValue = comboA.getSelectedItem().toString();
        destiny.setText(selectedValue);
 

        // TODO add your handling code here:
    }//GEN-LAST:event_comboAActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

      stationA.setVisible(true);  
      stationBNorth.setVisible(false); 
      stationBSouth.setVisible(false); 
      stationC.setVisible(false); 
      comboA.setVisible(true);
      comboBNorth.setVisible(false);
      comboBSouth.setVisible(false);
      comboC.setVisible(false);

       stationOutput.setText("Station A");

        String selectedValue = comboA.getSelectedItem().toString();
        destiny.setText(selectedValue);
 

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

      stationA.setVisible(false);  
      stationBNorth.setVisible(false); 
      stationBSouth.setVisible(false); 
      stationC.setVisible(true); 
      comboA.setVisible(false);
      comboBNorth.setVisible(false);
      comboBSouth.setVisible(false);
      comboC.setVisible(true);

      stationOutput.setText("Station C");

       String selectedValue = comboC.getSelectedItem().toString();
        destiny.setText(selectedValue);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void comboCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboCActionPerformed

        String selectedValue = comboC.getSelectedItem().toString();
        destiny.setText(selectedValue);
        
 

        // TODO add your handling code here:
    }//GEN-LAST:event_comboCActionPerformed

    private void comboBNorthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBNorthActionPerformed

        String selectedValue = comboBNorth.getSelectedItem().toString();
        destiny.setText(selectedValue);
 
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBNorthActionPerformed

    private void comboBSouthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBSouthActionPerformed

        String selectedValue = comboBSouth.getSelectedItem().toString();
        destiny.setText(selectedValue);
 
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBSouthActionPerformed

    private void jCalendar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCalendar1MouseClicked


        // TODO add your handling code here:
    }//GEN-LAST:event_jCalendar1MouseClicked

    private void jCalendar1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jCalendar1KeyPressed
  


        // TODO add your handling code here:
    }//GEN-LAST:event_jCalendar1KeyPressed

    private void jCalendar1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jCalendar1PropertyChange
  
        Date date = jCalendar1.getDate();
        String strDate = DateFormat.getDateInstance().format(date);
        dated.setText(strDate);


        // TODO add your handling code here:
    }//GEN-LAST:event_jCalendar1PropertyChange

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

String tim = times.getText();
String trin = trainid.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

String tim = jLabel7.getText();
String trin = jLabel6.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

String tim = jLabel9.getText();
String trin = jLabel8.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed

String tim = jLabel11.getText();
String trin = jLabel10.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
String tim = jLabel15.getText();
String trin = jLabel14.getText();
boardTime.setText(tim);
trainNumber.setText(trin);




    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed

String tim = jLabel45.getText();
String trin = jLabel44.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed

String tim = jLabel13.getText();
String trin = jLabel12.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
 String tim = jLabel51.getText();
String trin = jLabel50.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        
// TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton43ActionPerformed
 String tim = jLabel82.getText();
String trin = jLabel81.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton43ActionPerformed

    private void jButton44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton44ActionPerformed
 
 String tim = jLabel92.getText();
String trin = jLabel91.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        
// TODO add your handling code here:
    }//GEN-LAST:event_jButton44ActionPerformed

    private void jButton45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton45ActionPerformed
 String tim = jLabel94.getText();
String trin = jLabel93.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton45ActionPerformed

    private void jButton46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton46ActionPerformed
  String tim = jLabel96.getText();
String trin = jLabel95.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        

// TODO add your handling code here:
    }//GEN-LAST:event_jButton46ActionPerformed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed

  String tim = jLabel98.getText();
String trin = jLabel97.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton47ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed

  String tim = jLabel55.getText();
String trin = jLabel54.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed

  String tim = jLabel60.getText();
String trin = jLabel59.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
  String tim = jLabel62.getText();
String trin = jLabel61.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed

  String tim = jLabel64.getText();
String trin = jLabel63.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed

  String tim = jLabel66.getText();
String trin = jLabel65.getText();
boardTime.setText(tim);
trainNumber.setText(trin);



        // TODO add your handling code here:
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
  String tim = jLabel68.getText();
String trin = jLabel67.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed

  String tim = jLabel70.getText();
String trin = jLabel69.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed

  String tim = jLabel58.getText();
String trin = jLabel57.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed

  String tim = jLabel74.getText();
String trin = jLabel73.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
  String tim = jLabel76.getText();
String trin = jLabel75.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton40ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
String tim = jLabel100.getText();
String trin = jLabel99.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton48ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed

String tim = jLabel102.getText();
String trin = jLabel101.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed
String tim = jLabel104.getText();
String trin = jLabel103.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton50ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
String tim = jLabel106.getText();
String trin = jLabel105.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed

String tim = jLabel78.getText();
String trin = jLabel77.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton41ActionPerformed

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed
 String tim = jLabel136.getText();
String trin = jLabel80.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        


// TODO add your handling code here:
    }//GEN-LAST:event_jButton42ActionPerformed

    private void jButton66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton66ActionPerformed

 String tim = jLabel138.getText();
String trin = jLabel137.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton66ActionPerformed

    private void jButton67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton67ActionPerformed

String tim = jLabel140.getText();
String trin = jLabel139.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton67ActionPerformed

    private void jButton68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton68ActionPerformed
String tim = jLabel142.getText();
String trin = jLabel141.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton68ActionPerformed

    private void jButton69ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton69ActionPerformed

String tim = jLabel144.getText();
String trin = jLabel143.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton69ActionPerformed

    private void jButton70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton70ActionPerformed
String tim = jLabel146.getText();
String trin = jLabel145.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton70ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
String tim = jLabel79.getText();
String trin = jLabel72.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton71ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton71ActionPerformed
String tim = jLabel148.getText();
String trin = jLabel147.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton71ActionPerformed

    private void jButton72ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton72ActionPerformed
String tim = jLabel150.getText();
String trin = jLabel149.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton72ActionPerformed

    private void jButton74ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton74ActionPerformed

String tim = jLabel154.getText();
String trin = jLabel153.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton74ActionPerformed

    private void jButton75ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton75ActionPerformed

String tim = jLabel156.getText();
String trin = jLabel155.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton75ActionPerformed

    private void jButton76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton76ActionPerformed

String tim = jLabel158.getText();
String trin = jLabel157.getText();
boardTime.setText(tim);
trainNumber.setText(trin);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton76ActionPerformed

    private void jButton77ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton77ActionPerformed
String tim = jLabel160.getText();
String trin = jLabel159.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton77ActionPerformed

    private void jButton73ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton73ActionPerformed
String tim = jLabel152.getText();
String trin = jLabel151.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton73ActionPerformed

    private void jButton53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton53ActionPerformed
String tim = jLabel111.getText();
String trin = jLabel110.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton53ActionPerformed

    private void jButton54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton54ActionPerformed
String tim = jLabel113.getText();
String trin = jLabel112.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton54ActionPerformed

    private void jButton55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton55ActionPerformed

String tim = jLabel115.getText();
String trin = jLabel114.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton55ActionPerformed

    private void jButton56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton56ActionPerformed


String tim = jLabel117.getText();
String trin = jLabel116.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton56ActionPerformed

    private void jButton57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton57ActionPerformed

String tim = jLabel119.getText();
String trin = jLabel118.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton57ActionPerformed

    private void jButton58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton58ActionPerformed

String tim = jLabel121.getText();
String trin = jLabel120.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton58ActionPerformed

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed

String tim = jLabel109.getText();
String trin = jLabel108.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jButton59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton59ActionPerformed
String tim = jLabel123.getText();
String trin = jLabel122.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton59ActionPerformed

    private void jButton60ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton60ActionPerformed
String tim = jLabel125.getText();
String trin = jLabel124.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton60ActionPerformed

    private void jButton62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton62ActionPerformed
String tim = jLabel129.getText();
String trin = jLabel128.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton62ActionPerformed

    private void jButton63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton63ActionPerformed
String tim = jLabel131.getText();
String trin = jLabel130.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton63ActionPerformed

    private void jButton64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton64ActionPerformed
String tim = jLabel133.getText();
String trin = jLabel132.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton64ActionPerformed

    private void jButton65ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton65ActionPerformed
String tim = jLabel135.getText();
String trin = jLabel134.getText();
boardTime.setText(tim);
trainNumber.setText(trin);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton65ActionPerformed

    private void jButton61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton61ActionPerformed
String tim = jLabel127.getText();
String trin = jLabel126.getText();
boardTime.setText(tim);
trainNumber.setText(trin);


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton61ActionPerformed

    private void boardTimePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_boardTimePropertyChange
 
        
        try {
                 DateFormat sdf = new SimpleDateFormat("hh:mm a");     
                              String ds = boardTime.getText();
         String jf = stationOutput.getText();
       String df =  destiny.getText();      
             
                 Date d = sdf.parse(ds);  

             
          if(jf=="Station A" && df=="Station B")  
          {
           d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                                                 priceLabel.setText("50");       
           destinyTime.setText(sdf.format(d)+"");
          }
          else if(jf=="Station A" && df=="Station C")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(2));
                                                        priceLabel.setText("100");
           destinyTime.setText(sdf.format(d)+"");
          }
           else if(jf=="Station C" && df=="Station B")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                                         priceLabel.setText("50");

           destinyTime.setText(sdf.format(d)+"");
          }
           else if(jf=="Station C" && df=="Station A")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(2));
                         priceLabel.setText("100");
           destinyTime.setText(sdf.format(d)+"");
          }
          else if(jf=="Station B(NorthBound)" && df=="Station C")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                         priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }                                  
              else if(jf=="Station B(SouthBound)" && df=="Station A")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                         priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }          
          
        } catch (ParseException ex) {
            Logger.getLogger(scheduleForm.class.getName()).log(Level.SEVERE, null, ex);
        }
    



        // TODO add your handling code here:
    }//GEN-LAST:event_boardTimePropertyChange

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
 // this done button is for the programmer that will integrate this to the other UI

 
 
 
String trainNo = trainNumber.getText();
String station = stationOutput.getText();
String boardingTime = boardTime.getText();
String destination = destiny.getText();
String timeToDestination = destinyTime.getText();
String timeOfRide = dated.getText();
String dateOfBooking = book.getText();
String timeOfBooking = timerist.getText();
String age = ageLabel.getText();
String name = nameLabel.getText();
String gen = genderLabel.getText();
String prise = priceLabel.getText();
String id = idLabel.getText();
String password = passwordLabel.getText();

 paymentForm pf = new paymentForm();

              pf.trainNumber.setText(trainNo);
              pf.stationOutput.setText(station);
              pf.boardTime.setText(boardingTime);
              pf.destiny.setText(destination);
              pf.destinyTime.setText(timeToDestination);
              pf.dated.setText(timeOfRide);
              pf.book.setText(dateOfBooking);
              pf.timerist.setText(timeOfBooking);
              pf.ageLabel.setText(age);
              pf.nameLabel.setText(name);
              pf.genderLabel.setText(gen);
              pf.priceLabel.setText(prise);
              pf.idLabel.setText(id);
              pf.passwordLabel.setText(password);
              

                 this.dispose();
                 pf.setVisible(true); 



          
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jPanel9PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jPanel9PropertyChange
         String ds = boardTime.getText();
         String jf = stationOutput.getText();
       String df =  destiny.getText(); 
        
        try {
                 DateFormat sdf = new SimpleDateFormat("hh:mm a");     
          
               Date d = sdf.parse(ds);           
             
          if(jf=="Station A" && df=="Station B")  
          {
           d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                       
           destinyTime.setText(sdf.format(d)+"");
           priceLabel.setText("50");
          }
          else if(jf=="Station A" && df=="Station C")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(2));
                                  priceLabel.setText("100");
           destinyTime.setText(sdf.format(d)+"");
          }
           else if(jf=="Station C" && df=="Station B")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                                    priceLabel.setText("50");
                       
           destinyTime.setText(sdf.format(d)+"");
          }
           else if(jf=="Station C" && df=="Station A")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(2));
                                  priceLabel.setText("100");
           destinyTime.setText(sdf.format(d)+"");
          }
            else if(jf=="Station B(NorthBound)" && df=="Station C")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                                  priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }                                  
              else if(jf=="Station B(SouthBound)" && df=="Station A")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                                  priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }          
          
          
        } catch (ParseException ex) {
            Logger.getLogger(scheduleForm.class.getName()).log(Level.SEVERE, null, ex);
        }
    


        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel9PropertyChange

    private void destinyPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_destinyPropertyChange
         String ds = boardTime.getText();
         String jf = stationOutput.getText();
       String df =  destiny.getText(); 
        
        try {
                 DateFormat sdf = new SimpleDateFormat("hh:mm a");     
          
               Date d = sdf.parse(ds);           
             
          if(jf=="Station A" && df=="Station B")  
          {
           d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                   priceLabel.setText("50");      
           destinyTime.setText(sdf.format(d)+"");
          }
          else if(jf=="Station A" && df=="Station C")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(2));
                         priceLabel.setText("100");
           destinyTime.setText(sdf.format(d)+"");
          }
           else if(jf=="Station C" && df=="Station B")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                         priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }
           else if(jf=="Station C" && df=="Station A")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(2));
                         priceLabel.setText("100");
           destinyTime.setText(sdf.format(d)+"");
          }
          else if(jf=="Station B(NorthBound)" && df=="Station C")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                         priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }                                  
              else if(jf=="Station B(SouthBound)" && df=="Station A")
          {
                         d.setTime(d.getTime()+TimeUnit.HOURS.toMillis(1));
                         priceLabel.setText("50");
           destinyTime.setText(sdf.format(d)+"");
          }          
          
          
        } catch (ParseException ex) {
            Logger.getLogger(scheduleForm.class.getName()).log(Level.SEVERE, null, ex);
        }
    






        // TODO add your handling code here:
    }//GEN-LAST:event_destinyPropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(scheduleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(scheduleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(scheduleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(scheduleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new scheduleForm().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel ageLabel;
    private javax.swing.JLabel boardTime;
    private javax.swing.JLabel book;
    private javax.swing.JComboBox<String> comboA;
    private javax.swing.JComboBox<String> comboBNorth;
    private javax.swing.JComboBox<String> comboBSouth;
    private javax.swing.JComboBox<String> comboC;
    public javax.swing.JLabel dateDisplay;
    private javax.swing.JLabel dated;
    private javax.swing.JLabel destiny;
    private javax.swing.JLabel destinyTime;
    public javax.swing.JLabel genderLabel;
    public javax.swing.JLabel idLabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton61;
    private javax.swing.JButton jButton62;
    private javax.swing.JButton jButton63;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton67;
    private javax.swing.JButton jButton68;
    private javax.swing.JButton jButton69;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton70;
    private javax.swing.JButton jButton71;
    private javax.swing.JButton jButton72;
    private javax.swing.JButton jButton73;
    private javax.swing.JButton jButton74;
    private javax.swing.JButton jButton75;
    private javax.swing.JButton jButton76;
    private javax.swing.JButton jButton77;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    public javax.swing.JLabel nameLabel;
    public javax.swing.JLabel passwordLabel;
    public javax.swing.JLabel priceLabel;
    private javax.swing.JPanel stationA;
    private javax.swing.JPanel stationBNorth;
    private javax.swing.JPanel stationBSouth;
    private javax.swing.JPanel stationC;
    private javax.swing.JLabel stationOutput;
    public javax.swing.JLabel timedisplay;
    private javax.swing.JLabel timerist;
    private javax.swing.JLabel times;
    private javax.swing.JLabel trainNumber;
    private javax.swing.JLabel trainid;
    // End of variables declaration//GEN-END:variables
}
